// Use the "beforeRender" or "afterRender" hook
// to manipulate and control the report generation
async function beforeRender (req, res) {
function multiply(a, b) {
  return a * b;
}

}